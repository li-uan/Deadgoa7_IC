#include "tune.h"
#include "balance.h"

/* =====================================================================
 * ���ߴ��ڵ��Σ�UART_2��P10.5 �� / P10.6 �գ�115200��
 *
 * ��λ�������ÿ���� \n �� \r ��β����
 *   P300      ���� KP
 *   D8        ���� KD
 *   Z2.5      ����ƽ�����
 *   ?         ���̻ش�һ֡״̬
 *
 * ��λ��ÿ 100ms �Զ��ش���
 *   $ang=1.23,P=300.0,D=0.0,Z=1.78,duty=120,spd=3,f=0,arm=1
 * ===================================================================== */

#define TUNE_UART           (UART_2)
#define TUNE_BAUD           (115200)
#define TUNE_TX_PIN         (UART2_TX_P10_5)
#define TUNE_RX_PIN         (UART2_RX_P10_6)

static char   s_buf[64];
static uint8  s_len = 0;

/* ---------- ����С���ߣ����� printf������ռ�õ��Դ��ڣ� ---------- */
static void tx_str(const char *s)
{
    uart_write_string(TUNE_UART, s);
}

static void tx_int(int32 v)
{
    char tmp[12];
    uint8 i = 0;
    uint8 neg = 0;
    uint8 n = 0;

    if (v < 0) { neg = 1; v = -v; }
    if (v == 0) { tmp[i++] = '0'; }
    while (v > 0) { tmp[i++] = (char)('0' + (v % 10)); v /= 10; }
    if (neg) tmp[i++] = '-';
    while (i > 0) { s_buf[n++] = tmp[--i]; }
    s_buf[n] = '\0';
    tx_str(s_buf);
}

/* ��λС����������� 300.00 */
static void tx_float2(float v)
{
    char tmp[16];
    uint8 i = 0;
    uint8 n = 0;
    int32 whole;
    int32 frac;
    uint8 neg = 0;

    if (v < 0.0f) { neg = 1; v = -v; }
    whole = (int32)v;
    frac  = (int32)((v - (float)whole) * 100.0f + 0.5f);
    if (frac >= 100) { frac -= 100; whole += 1; }

    if (whole == 0) tmp[i++] = '0';
    while (whole > 0) { tmp[i++] = (char)('0' + (whole % 10)); whole /= 10; }
    if (neg) tmp[i++] = '-';
    while (i > 0) { s_buf[n++] = tmp[--i]; }
    s_buf[n++] = '.';
    s_buf[n++] = (char)('0' + (frac / 10));
    s_buf[n++] = (char)('0' + (frac % 10));
    s_buf[n] = '\0';
    tx_str(s_buf);
}

/* �򵥸��������"-12.34" -> -12.34�������Ƿ�ɹ� */
static uint8 parse_float(const char *s, float *out)
{
    float v = 0.0f;
    float f = 0.1f;
    uint8 neg = 0;
    uint8 dot = 0;
    uint8 has = 0;

    while (*s == ' ') s++;
    if (*s == '-') { neg = 1; s++; }
    else if (*s == '+') { s++; }

    while (*s)
    {
        char c = *s;
        if (c >= '0' && c <= '9')
        {
            has = 1;
            if (!dot) v = v * 10.0f + (float)(c - '0');
            else      { v += (float)(c - '0') * f; f *= 0.1f; }
        }
        else if (c == '.' && !dot) { dot = 1; }
        else break;
        s++;
    }
    if (!has) return 0;
    *out = neg ? -v : v;
    return 1;
}

/* ---------- ����� ---------- */
static void handle_line(char *line)
{
    char cmd = line[0];
    float v;

    if (cmd == 'P' || cmd == 'p')
    {
        if (parse_float(&line[1], &v)) { balance_set_kp(v); tx_str("OK P\r\n"); }
    }
    else if (cmd == 'D' || cmd == 'd')
    {
        if (parse_float(&line[1], &v)) { balance_set_kd(v); tx_str("OK D\r\n"); }
    }
    else if (cmd == 'Z' || cmd == 'z')
    {
        if (parse_float(&line[1], &v)) { balance_set_zero(v); tx_str("OK Z\r\n"); }
    }
    else if (cmd == '?')
    {
        tune_send_telemetry();
    }
}

void tune_init(void)
{
    uart_init(TUNE_UART, TUNE_BAUD, TUNE_TX_PIN, TUNE_RX_PIN);
    s_len = 0;
}

void tune_poll(void)
{
    uint8 c;

    while (uart_query_byte(TUNE_UART, &c))
    {
        if (c == '\n' || c == '\r')
        {
            if (s_len > 0)
            {
                s_buf[s_len] = '\0';
                handle_line(s_buf);
                s_len = 0;
            }
        }
        else if (s_len < (uint8)(sizeof(s_buf) - 1))
        {
            s_buf[s_len++] = (char)c;
        }
        else
        {
            s_len = 0;      /* �������� */
        }
    }
}

void tune_send_telemetry(void)
{
    /* $ang=...,P=...,D=...,Z=...,duty=...,spd=...,f=...,arm=... */
    tx_str("$ang=");
    tx_float2(balance_get_angle());
    tx_str(",P=");
    tx_float2(balance_get_kp());
    tx_str(",D=");
    tx_float2(balance_get_kd());
    tx_str(",Z=");
    tx_float2(balance_get_zero());
    tx_str(",duty=");
    tx_int(balance_get_duty());
    tx_str(",spd=");
    tx_int((int32)balance_get_speed());
    tx_str(",f=");
    tx_int((int32)balance_get_fault());
    tx_str(",arm=");
    tx_int(balance_is_armed() ? 1 : 0);
    tx_str("\r\n");
}
