#include "balance.h"
#include "balance_config.h"
#include <math.h>

#define RAD2DEG                 (57.29578f)
#define CTRL_DT                 ((float)CTRL_PERIOD_MS / 1000.0f)

/* ===================== �ڲ�״̬ ===================== */
static float g_angle        = 0.0f;     /* �����˲������ǣ��㣩 */
static float g_gyro_rate    = 0.0f;     /* �˲������ǽ��ٶȣ���/s�� */
static float g_gyro_yaw     = 0.0f;     /* �˲���� yaw ���ٶȣ���/s�� */
static float g_speed        = 0.0f;     /* ������ƽ���ٶ� */
static float g_speed_i      = 0.0f;     /* �ٶȻ����� */
static int16 g_duty         = 0;
static uint8 g_armed        = 0;
static uint16 g_arm_cnt     = 0;
static uint16 g_fall_cnt    = 0;
static uint16 g_key_cnt     = 0;
static uint16 g_stall_cnt   = 0;
static uint16 g_runaway_cnt = 0;
static uint16 g_imu0_cnt    = 0;
static uint16 g_run_ms      = 0;
static uint16 g_start_cnt   = 0;
static uint8  g_fault       = 0;        /* 0�� 1��ͣ 2ˤ�� 3��ת 4ʧ�� 5IMU���� */

/* ����ʱ�ɵ����������ߴ��ڿ��Ըģ� */
static float  g_kp          = BALANCE_KP;
static float  g_kd          = BALANCE_KD;
static float  g_zero        = BALANCE_ANGLE_ZERO;

/* ===================== С���� ===================== */
static float clampf(float v, float lo, float hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

/* �������ǣ������ + yaw �ᣨ�ѳ˷��ţ� */
static void imu_read_tilt_rate(float *tilt_rate, float *yaw_rate)
{
    imu660rc_get_gyro();

#if (IMU_TILT_AXIS == 0)
    *tilt_rate = imu660rc_gyro_transition(imu660rc_gyro_x) * (float)IMU_TILT_SIGN;
#elif (IMU_TILT_AXIS == 1)
    *tilt_rate = imu660rc_gyro_transition(imu660rc_gyro_y) * (float)IMU_TILT_SIGN;
#else
    *tilt_rate = imu660rc_gyro_transition(imu660rc_gyro_z) * (float)IMU_TILT_SIGN;
#endif

#if (IMU_YAW_AXIS == 0)
    *yaw_rate = imu660rc_gyro_transition(imu660rc_gyro_x) * (float)IMU_YAW_SIGN;
#elif (IMU_YAW_AXIS == 1)
    *yaw_rate = imu660rc_gyro_transition(imu660rc_gyro_y) * (float)IMU_YAW_SIGN;
#else
    *yaw_rate = imu660rc_gyro_transition(imu660rc_gyro_z) * (float)IMU_YAW_SIGN;
#endif
}

/* �ü��ٶ���������
 * �� X ��ת -> ������ Y-Z ƽ�� -> atan2(ay, az)
 * �� Y ��ת -> ������ X-Z ƽ�� -> atan2(ax, az)
 * �� Z ��ת -> ������ X-Y ƽ�� -> atan2(ax, ay)  */
static float imu_acc_angle(void)
{
    float ax, ay, az;

    imu660rc_get_acc();
    ax = imu660rc_acc_transition(imu660rc_acc_x);
    ay = imu660rc_acc_transition(imu660rc_acc_y);
    az = imu660rc_acc_transition(imu660rc_acc_z);

#if (IMU_TILT_AXIS == 0)
    return atan2f(ay, az) * RAD2DEG * (float)IMU_TILT_SIGN;
#elif (IMU_TILT_AXIS == 1)
    return atan2f(ax, az) * RAD2DEG * (float)IMU_TILT_SIGN;
#else
    return atan2f(ax, ay) * RAD2DEG * (float)IMU_TILT_SIGN;
#endif
}

static void encoder_read(int16 *l, int16 *r)
{
    int16 raw_l = encoder_get_count(ENC_L);
    int16 raw_r = encoder_get_count(ENC_R);
    encoder_clear_count(ENC_L);
    encoder_clear_count(ENC_R);

    *l = (ENC_L_INVERT) ? (int16)(-raw_l) : raw_l;
    *r = (ENC_R_INVERT) ? (int16)(-raw_r) : raw_r;
}

/* ���һ�������ռ�ձȣ������� */
static void motor_output(uint8 is_left, int16 duty)
{
    uint8 dir_level = 0;
    uint32 mag;

    if (duty < 0)
    {
        dir_level = 1;
        duty = (int16)(-duty);
    }
    if (is_left)
    {
        if (MOTOR_L_INVERT) dir_level = (uint8)(!dir_level);
    }
    else
    {
        if (MOTOR_R_INVERT) dir_level = (uint8)(!dir_level);
    }

    mag = (uint32)clampf((float)duty, 0.0f, (float)MOTOR_DUTY_MAX);

#if (MOTOR_MODE == 0)
    if (is_left) gpio_set_level(MOTOR_L_DIR, dir_level);
    else         gpio_set_level(MOTOR_R_DIR, dir_level);

    if (is_left) pwm_set_duty(MOTOR_L_PWM, mag);
    else         pwm_set_duty(MOTOR_R_PWM, mag);
#else
    if (is_left)
    {
        pwm_set_duty(MOTOR_L_PWM,  dir_level ? 0u : mag);
        pwm_set_duty(MOTOR_L_PWM2, dir_level ? mag : 0u);
    }
    else
    {
        pwm_set_duty(MOTOR_R_PWM,  dir_level ? 0u : mag);
        pwm_set_duty(MOTOR_R_PWM2, dir_level ? mag : 0u);
    }
#endif
}

static void motor_stop(void)
{
    motor_output(1, 0);
    motor_output(0, 0);
    g_duty = 0;
}

/* ===================== ��ʼ�� ===================== */
void balance_init(void)
{
#if (TEST_MODE == 4)
    /* ��ƽ/PWM ɨ�裺4 ����ȫ����� PWM���� 20% ռ�ձ������ */
    pwm_init(ATOM0_CH0_P21_2, 17000, 0);
    pwm_init(ATOM0_CH1_P21_3, 17000, 0);
    pwm_init(ATOM0_CH2_P21_4, 17000, 0);
    pwm_init(ATOM0_CH3_P21_5, 17000, 0);
    pit_ms_init(CCU60_CH0, CTRL_PERIOD_MS);
    return;
#endif

    /* 1. ��� */
    pwm_init(MOTOR_L_PWM, 17000, 0);
    pwm_init(MOTOR_R_PWM, 17000, 0);
#if (MOTOR_MODE == 0)
    gpio_init(MOTOR_L_DIR, GPO, 0, GPO_PUSH_PULL);
    gpio_init(MOTOR_R_DIR, GPO, 0, GPO_PUSH_PULL);
#else
    pwm_init(MOTOR_L_PWM2, 17000, 0);
    pwm_init(MOTOR_R_PWM2, 17000, 0);
#endif
    motor_stop();

    /* 2. ������ */
    encoder_dir_init(ENC_L, ENC_L_A, ENC_L_B);
    encoder_dir_init(ENC_R, ENC_R_A, ENC_R_B);

    /* 3. IMU */
    while (imu660rc_init(IMU660RC_QUARTERNION_DISABLE) != 0)
    {
        printf("IMU660RC init failed, retry...\r\n");
        system_delay_ms(300);
    }
    printf("IMU660RC init ok\r\n");

    /* 4. ��ͣ���� */
    gpio_init(KEY_STOP_PIN, GPI, 0, GPI_PULL_UP);

    /* 5. 5ms �����ж� */
    pit_ms_init(CCU60_CH0, CTRL_PERIOD_MS);
    printf("balance ready. Hold the car upright (+-3 deg) for 1s to ARM.\r\n");
}

/* ===================== 5ms ���� ===================== */
void balance_control_isr(void)
{
    float tilt_rate, yaw_rate, acc_ang;
    float target_angle, err, out;
    float yaw_corr = 0.0f;
    int16 enc_l, enc_r;
    float speed_now;

#if (TEST_MODE == 2)
    {
        static uint16 test_t = 0;
        test_t++;
        if (test_t < 300)       { motor_output(1, MOTOR_TEST_DUTY);  motor_output(0, MOTOR_TEST_DUTY); }
        else if (test_t < 500)  { motor_stop(); }
        else if (test_t < 800)  { motor_output(1, -MOTOR_TEST_DUTY); motor_output(0, -MOTOR_TEST_DUTY); }
        else if (test_t < 1000) { motor_stop(); }
        else                    { test_t = 0; }
        return;
    }
#endif

    /* ---------- 1. ���� ---------- */
    imu_read_tilt_rate(&tilt_rate, &yaw_rate);
    acc_ang = imu_acc_angle();

    g_gyro_rate += GYRO_LPF_ALPHA * (tilt_rate - g_gyro_rate);
    g_gyro_yaw  += GYRO_LPF_ALPHA * (yaw_rate  - g_gyro_yaw);

    g_angle = 0.98f * (g_angle + g_gyro_rate * CTRL_DT) + 0.02f * acc_ang;

    /* �ϵ�ǰ 100ms �ü��ٶȽǳ�ʼ�� */
    if (g_start_cnt < 20)
    {
        g_start_cnt++;
        g_angle = acc_ang;
        g_gyro_rate = 0.0f;
        motor_stop();
        return;
    }

    /* ---------- 2. ��ͣ���� ---------- */
    {
        uint8 key_down = (gpio_get_level(KEY_STOP_PIN) == 0) ? 1 : 0;
#if (!KEY_STOP_ACTIVE_LOW)
        key_down = (uint8)(!key_down);
#endif
        if (key_down)
        {
            if (g_key_cnt < 1000) g_key_cnt++;
            if (g_key_cnt >= 3)
            {
                g_armed = 0;
                g_arm_cnt = 0;
                g_speed_i = 0.0f;
                g_fault = 1;
                motor_stop();
                return;
            }
        }
        else
        {
            g_key_cnt = 0;
        }
    }

    /* ---------- 3. ����ģʽ��ֻ�������� ---------- */
#if (TEST_MODE == 1)
    motor_stop();
    return;
#endif

    /* ---------- 4. IMU ���� ---------- */
    if (imu660rc_gyro_x == 0 && imu660rc_gyro_y == 0 && imu660rc_gyro_z == 0 &&
        imu660rc_acc_x == 0 && imu660rc_acc_y == 0 && imu660rc_acc_z == 0)
    {
        if (g_imu0_cnt < 60000) g_imu0_cnt++;
        if (g_imu0_cnt > (IMU_ZERO_TIME_MS / CTRL_PERIOD_MS))
        {
            g_armed = 0;
            g_fault = 5;
            motor_stop();
            return;
        }
    }
    else
    {
        g_imu0_cnt = 0;
    }

    /* ---------- 5. ˤ�� ---------- */
    if (fabsf(g_angle - g_zero) > FALL_ANGLE)
    {
        if (++g_fall_cnt > (FALL_HOLD_MS / CTRL_PERIOD_MS))
        {
            g_armed = 0;
            g_arm_cnt = 0;
            g_speed_i = 0.0f;
            g_fault = 2;
            motor_stop();
        }
        return;
    }
    g_fall_cnt = 0;

    /* ---------- 6. �����ж� ---------- */
    if (!g_armed)
    {
        if (fabsf(g_angle - g_zero) < ARM_ANGLE_TOL)
        {
            if (++g_arm_cnt >= (ARM_HOLD_MS / CTRL_PERIOD_MS))
            {
                g_armed = 1;
                g_arm_cnt = 0;
                g_speed_i = 0.0f;
                g_run_ms = 0;
                g_fault = 0;
            }
        }
        else
        {
            g_arm_cnt = 0;
        }
        motor_stop();
        return;
    }

    /* ---------- 7. �ٶȻ���Ĭ�Ϲرգ� ---------- */
    encoder_read(&enc_l, &enc_r);
    speed_now = ((float)enc_l + (float)enc_r) * 0.5f;
    g_speed += 0.3f * (speed_now - g_speed);

    target_angle = g_zero;
#if (SPEED_LOOP_ENABLE)
    {
        float speed_err = g_speed - SPEED_TARGET;
        float corr;

        g_speed_i += SPEED_KI * speed_err * CTRL_DT;
        g_speed_i = clampf(g_speed_i, -SPEED_I_LIMIT, SPEED_I_LIMIT);

        corr = SPEED_KP * speed_err + g_speed_i;
        target_angle -= corr;
    }
#endif

    /* ---------- 8. ֱ�� PD ---------- */
    err = g_angle - target_angle;
    out = g_kp * err + g_kd * g_gyro_rate;

    /* ---------- 9. ת����٣�Ĭ�Ϲرգ� ---------- */
#if (YAW_DAMP_ENABLE)
    yaw_corr = YAW_KP * (g_gyro_yaw - YAW_TARGET);
#endif

    /* ---------- 10. ������ ---------- */
    if (g_run_ms < (SOFT_START_MS / CTRL_PERIOD_MS)) g_run_ms++;
    {
        float ramp_max = (float)MOTOR_DUTY_MAX * ((float)g_run_ms * (float)CTRL_PERIOD_MS) / (float)SOFT_START_MS;
        if (ramp_max > (float)MOTOR_DUTY_MAX) ramp_max = (float)MOTOR_DUTY_MAX;
        out = clampf(out, -ramp_max, ramp_max);
    }

    /* ---------- 11. ��� ---------- */
    out = clampf(out, -(float)MOTOR_DUTY_MAX, (float)MOTOR_DUTY_MAX);
    g_duty = (int16)out;

    motor_output(1, (int16)clampf(out + yaw_corr, -(float)MOTOR_DUTY_MAX, (float)MOTOR_DUTY_MAX));
    motor_output(0, (int16)clampf(out - yaw_corr, -(float)MOTOR_DUTY_MAX, (float)MOTOR_DUTY_MAX));

    /* ---------- 12. ��ת / ʧ�� ---------- */
    if (fabsf((float)g_duty) > (float)STALL_DUTY_TH && enc_l == 0 && enc_r == 0)
    {
        if (g_stall_cnt < 60000) g_stall_cnt++;
        if (g_stall_cnt > (STALL_TIME_MS / CTRL_PERIOD_MS))
        {
            g_armed = 0;
            g_fault = 3;
            motor_stop();
        }
    }
    else
    {
        g_stall_cnt = 0;
    }

    if (fabsf(g_angle - g_zero) > RUNAWAY_ANGLE)
    {
        if (g_runaway_cnt < 60000) g_runaway_cnt++;
        if (g_runaway_cnt > (RUNAWAY_TIME_MS / CTRL_PERIOD_MS))
        {
            g_armed = 0;
            g_fault = 4;
            motor_stop();
        }
    }
    else
    {
        g_runaway_cnt = 0;
    }
}

/* ===================== ���Դ�ӡ ===================== */
void balance_debug_print(void)
{
    printf("ang_x100=%d rate_x10=%d gx=%d gy=%d gz=%d ax=%d ay=%d az=%d spd_x10=%d duty=%d fault=%d %s\r\n",
           (int)(g_angle * 100.0f),
           (int)(g_gyro_rate * 10.0f),
           (int)imu660rc_gyro_x,
           (int)imu660rc_gyro_y,
           (int)imu660rc_gyro_z,
           (int)imu660rc_acc_x,
           (int)imu660rc_acc_y,
           (int)imu660rc_acc_z,
           (int)(g_speed * 10.0f),
           (int)g_duty,
           (int)g_fault,
           g_armed ? "ARMED" : "disarmed");
}

/* ===================== ����ʱ�����ӿ� ===================== */
void  balance_set_kp(float v)   { g_kp = v; }
void  balance_set_kd(float v)   { g_kd = v; }
void  balance_set_zero(float v) { g_zero = v; }

float balance_get_kp(void)      { return g_kp; }
float balance_get_kd(void)      { return g_kd; }
float balance_get_zero(void)    { return g_zero; }

float balance_get_angle(void)   { return g_angle; }
float balance_get_speed(void)   { return g_speed; }
int16 balance_get_duty(void)    { return g_duty; }
uint8 balance_is_armed(void)    { return g_armed; }
uint8 balance_get_fault(void)   { return g_fault; }
